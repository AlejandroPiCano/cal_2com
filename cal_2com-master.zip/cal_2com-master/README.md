# cal
Educational Git project. Creates a simple calculator in HTML and JavaScript in short steps. 
